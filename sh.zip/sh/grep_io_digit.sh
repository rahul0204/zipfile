Q. Display lines containing any digit
   in the range 1-9 redirect output to output.txt(use grep command) 

#!/bin/sh
grep [1-9] info.txt > output.txt

