Q .Display date date in 
   mm/dd/yy format redirect output to output.txt

#!/bin/sh
date +%D > output.txt
