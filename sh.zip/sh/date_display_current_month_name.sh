Q . Display current month name 

#!/bin/sh
date +%b
