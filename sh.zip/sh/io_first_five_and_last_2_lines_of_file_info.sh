Q. Display first five and last 2 lines of file info.txt
   (use input redirection)

#!/bin/bash
head -n 5 | tail -n 2  < info.txt
